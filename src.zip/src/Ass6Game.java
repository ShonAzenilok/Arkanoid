import arkanoid.gamesetup.GameFlow;
import arkanoid.interfaces.LevelInformation;
import arkanoid.levels.DirectHit;
import arkanoid.levels.Green3;
import arkanoid.levels.WideEasy;

import java.util.LinkedList;
import java.util.List;

/**
 * @author sean azenilok 209114370
 * main class that runs the game.
 */
public class Ass6Game {
    /**
     * sets up the game and runs it.
     * @param args gets nothing.
     */
    public static void main(String[] args) {
        List<LevelInformation> levels = new LinkedList<>(); //create a list of levels
        if (args.length == 0 || args[0].equals("${args}"))  {
            levels.add(new DirectHit());
            levels.add(new WideEasy());
            levels.add(new Green3());
        } else {
            for (String arg : args) {
                if (arg.equals("1")) { //level 1 - Direct Hit
                    levels.add(new DirectHit());
                } else if (arg.equals("2")) { //level 2 - Wide Easy
                    levels.add(new WideEasy());
                } else if (arg.equals("3")) { //level 3 - Green3
                    levels.add(new Green3());
                }
            }
        }
        GameFlow game = new GameFlow();
        game.runLevels(levels);

    }
}