package arkanoid.interfaces;

import arkanoid.gamesetup.Velocity;
import arkanoid.shapes.Ball;
import arkanoid.shapes.Point;
import arkanoid.shapes.Rectangle;

/**
 * @author sean azenilok 20911437
 * interface for all collidable objects.
 */
public interface Collidable {
    /**
     * Return the "collision shape" of the object.
     * @return Rectangle object
     */
    Rectangle getCollisionRectangle();

    /**
     * Notify the object that we collided with it at collisionPoint with
     * a given velocity.
     * @param hitter the ball that makes the hit
     * @param collisionPoint a point where collision occurred
     * @param currentVelocity the currents velocity of the object that we collided with
     * @return new velocity expected after the hit (based on the force the object inflicted on us).
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}