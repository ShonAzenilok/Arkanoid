package arkanoid.interfaces;

import arkanoid.gamesetup.Velocity;
import arkanoid.shapes.Block;

import java.util.List;

/**
 * interface with information about the level of the game.
 */
public interface LevelInformation {
    /**
     * @return the amount of balls left.
     */
    int numberOfBalls();

    /**
     * Note that initialBallVelocities().size() == numberOfBalls().
     * @return The initial velocity of each ball
     */
    List<Velocity> initialBallVelocities();

    /**
     * @return the paddle speed
     */
    int paddleSpeed();

    /**
     * @return the paddle width
     */
    int paddleWidth();

    /**
     * @return the level name will be displayed at the top of the screen.
     */
    String levelName();

    /**
     * @return a sprite with the background of the level
     */
    Sprite getBackground();

    /**
     * @return The Blocks that make up this level, each block contains
     * its size, color and location.
     */
    List<Block> blocks();

    /**
     * @return Number of blocks that should be removed
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size();
     */
    int numberOfBlocksToRemove();
}