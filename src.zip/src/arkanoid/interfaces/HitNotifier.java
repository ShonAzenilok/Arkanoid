package arkanoid.interfaces;

/**
 * hit notifier interface for listeners to hits.
 */
public interface HitNotifier {
    /**
     * Add hl as a listener to hit events.
     * @param hl the listener that will be added
     */
    void addHitListener(HitListener hl);

    /**
     * Remove hl from the list of listeners to hit events.
     * @param hl the listener that will be removed
     */
    void removeHitListener(HitListener hl);
}