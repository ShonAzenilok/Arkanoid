package arkanoid.interfaces;

import biuoop.DrawSurface;

/**
 * animation interface.
 * @author sean azenilok 209114370
 */

public interface Animation {
    /**
     * draws one frame of the game.
     * @param d the drawing surface that will be drawn on
     */
    void doOneFrame(DrawSurface d);

    /**
     * stopping conditions for the game.
     * @return true or false if the game should stop
     */
    boolean shouldStop();
}