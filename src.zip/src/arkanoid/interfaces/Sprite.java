package arkanoid.interfaces;

import biuoop.DrawSurface;
/**
 * the sprites interface.
 * @author sean azenilok 209114370
 */
public interface Sprite {
    /**
     * draw the sprite to the screen.
     * @param d the given drawSurafce
     */
    void drawOn(DrawSurface d);

    /**
     * notify the sprite that time has passed.
     */
    void timePassed();
}