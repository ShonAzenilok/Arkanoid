package arkanoid.gamesetup;

import arkanoid.interfaces.Animation;
import arkanoid.interfaces.Collidable;
import arkanoid.interfaces.LevelInformation;
import arkanoid.interfaces.Sprite;
import arkanoid.shapes.Point;
import arkanoid.shapes.Rectangle;
import arkanoid.shapes.*;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import biuoop.Sleeper;

import java.awt.*;
import java.util.LinkedList;
import java.util.List;

/**
 * game class hold all game elements.
 */
public class GameLevel implements Animation {
    private AnimationRunner runner;
    private boolean running;
    private SpriteCollection sprites;
    private GameEnvironment environment;

    private Sleeper sleeper;
    private biuoop.KeyboardSensor keyboard;

    private BlockRemover blockRemover;
    private Counter remainingBlocks;
    private BallRemover ballRemover;
    private Counter remainingBalls;
    private ScoreTrackingListener scoreTrackingListener;
    private Counter score;
    private ScoreIndicator indicator;
    private LevelInformation level;

    /**
     *constructor for game.
     * create a list of sprites environment and the board.
     */
    public GameLevel(LevelInformation information, AnimationRunner ar, KeyboardSensor ks, ScoreTrackingListener st) {
        this.runner = ar;
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.sleeper = new Sleeper();
        this.keyboard = ks;
        this.remainingBlocks = new Counter();
        this.remainingBalls = new Counter();
        this.score = new Counter();
        this.scoreTrackingListener = st;
        this.level = information;
        this.indicator = new ScoreIndicator(new Rectangle(new Point(0, 0), 800, 30),
                this.level.levelName());
        this.running = false;
    }


    /**
     * adds a collidable to the collidables list.
     * @param c the collidable that will be added
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * adds a sprite to the sprite list.
     * @param s the sprite that will be added
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }
    @Override
    public void doOneFrame(DrawSurface d) {
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed();
        if (this.keyboard.isPressed("p")) {
            Animation pause = new KeyPressStoppableAnimation(this.keyboard, "space", new PauseScreen(this.keyboard));
            this.runner.run(pause);
        }
    }

    @Override
    public boolean shouldStop() {
        this.indicator.setScore(this.scoreTrackingListener.getScore());
        if (this.blockRemover.getRemainingBlocks() == 0 || this.ballRemover.getRemainingBalls() == 0) { //check if player won
            if (this.blockRemover.getRemainingBlocks() == 0) {
                this.scoreTrackingListener.addToScore(100); //add 100 to score if player won
            } else {
                Animation loss = new KeyPressStoppableAnimation(this.keyboard,"space",
                        new LossScreen(this.keyboard,this.scoreTrackingListener));
                this.runner.run(loss);
                this.runner.getGui().close();
            }
            return true;
        }
        return false;
    }

    /**
     * create border of game.
     */
    private void createBorder() {
        this.indicator.setScore(this.scoreTrackingListener.getScore());
        //add the border as a block
        sprites.addSprite(level.getBackground());
        //create walls
        Block leftWall = new Block(new Rectangle(new Point(0, 0), 50, 600), Color.darkGray,
                Color.black);
        leftWall.addToGame(this);
        Block rightWall = new Block(new Rectangle(new Point(750, 0), 50, 600), Color.darkGray,
                Color.black);
        rightWall.addToGame(this);
        Block upperWall = new Block(new Rectangle(new Point(50, 0), 700, 50), Color.darkGray,
                Color.black);
        upperWall.addToGame(this);

    }

    /**
     * Initialize a new game: create the Blocks Ball and Paddle
     * and add them to the game.
     */
    public void initialize() {
        this.createBorder(); //create border
        //create "Death region"
        Block lowerWall = new Block(new Rectangle(new Point(50, 599), 700, 10), Color.pink,
                Color.black);
        lowerWall.addToGame(this);
        //add score indicator to game
       indicator.addToGame(this);

        //create the balls
        List<Ball> balls = new LinkedList<>(); //balls list
        List<Velocity> vel = level.initialBallVelocities(); //balls velocity list
        remainingBalls.increase(level.numberOfBalls()); //set the amount of balls
        for (int i = 0; i < level.numberOfBalls(); i++) {
            balls.add(new Ball(410 - (i) * 30, 399, 8, Color.red, Color.black, this.environment));
            balls.get(i).setVelocity(vel.get(i));
            balls.get(i).addToGame(this);
        }
        //add death region as listener to balls.
        ballRemover = new BallRemover(this, remainingBalls);
        lowerWall.addHitListener(ballRemover);

        //create the blocks
        List<Block> blocks = level.blocks();
        remainingBlocks.increase(level.numberOfBlocksToRemove()); //get blocks amount
        blockRemover = new BlockRemover(this, remainingBlocks); //create a new block-remover
        for (Block block: blocks) {
            block.addToGame(this);
            block.addHitListener(scoreTrackingListener); //add score tracking as a listener
            block.addHitListener(blockRemover); // add block remover as a listener for all blocks that can be removed
        }

        //create the paddle
        Paddle player = new Paddle(new Rectangle(new Point(400 - (level.paddleWidth() / 2), 550), level.paddleWidth(), 15),
                new Color(255, 174, 0), Color.black, this, level.paddleSpeed());
        player.addToGame(this);



    }

    /**
     * Run the game -- start the animation loop.
     */
    public void run() {
        this.running = true;
        this.runner.run(new CountdownAnimation(1.5, 3, this.sprites));
        this.runner.run(this);
    }

    /**
     * getter for keyboard sensor.
     * @return a keyboard sensor
     */
    public KeyboardSensor getKeyboard() {
        return this.keyboard;
    }
    /**
     * remove a collidable from game collidables list when it was hit.
     * @param c the collidable that will be removed
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }

    /**
     * remove a sprite from game sprite collection when it was hit.
     * @param s the sprite that will be removed
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }
}
