package arkanoid.gamesetup;

/**
 * class for counting things.
 * @author sean azenilok 209114370
 */
public class Counter {
    private int counter;

    /**
     * constructor for counter.
     */
    public Counter() {
        this.counter = 0;
    }

    /**
     * add number to current count.
     * @param number the number that will be added
     */
    public void increase(int number) {
        this.counter += number;
    }

    /**
     * subtract number from current count.
     * @param number the number that will be removed
     */
    public void decrease(int number) {
        this.counter -= number;
    }

    /**
     * get current count.
     * @return the current count
     */
    public int getValue() {
      return this.counter;
    }
}