package arkanoid.gamesetup;

import arkanoid.interfaces.HitListener;
import arkanoid.shapes.Ball;
import arkanoid.shapes.Block;

/**
 * @author sean azenilok 209114370
 * a BlockRemover is in charge of removing blocks from the game, as well as keeping count
 * of the number of blocks that remain.
 */
public class BlockRemover implements HitListener {
    private GameLevel game;
    private Counter remainingBlocks;

    /**
     * constructor for BlockRemover.
     * @param game the game object where it will run
     * @param remainingBlocks the amount of remaining blocks
     */
    public BlockRemover(GameLevel game, Counter remainingBlocks) {
        this.game = game;
        this.remainingBlocks = new Counter();
        this.remainingBlocks.increase(remainingBlocks.getValue());
    }

    /**
     * Blocks that are hit should be removed
     * from the game. Remember to remove this listener from the block
     * that is being removed from the game.
     * @param beingHit the Block that is being hit
     * @param hitter the Ball that hits the block
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        beingHit.removeFromGame(game);
        beingHit.removeHitListener(this);
        this.remainingBlocks.decrease(1);
    }

    /**
     * getter for remainingBlocks.
     * @return the amount of remaining blocks
     */
    public int getRemainingBlocks() {
        return this.remainingBlocks.getValue();
    }
}