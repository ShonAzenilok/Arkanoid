package arkanoid.gamesetup;

import arkanoid.interfaces.HitListener;
import arkanoid.shapes.Ball;
import arkanoid.shapes.Block;

/**
 * class that makes a scoreboard.
 * @author sean azenilok 209114370
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;

    /**
     * constructor.
     * @param scoreCounter the current score
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    /**
     * increases points by 5.
     * @param beingHit the Block that is being hit
     * @param hitter the Ball that hits the block
     */
    public void hitEvent(Block beingHit, Ball hitter) {
       this.currentScore.increase(5);
       beingHit.removeHitListener(this);
    }

    /**
     * get the current score.
     * @return the score
     */
    public int getScore() {
        return this.currentScore.getValue();
    }

    /**
     * add to score (like in case of clearing all the blocks).
     * @param number the amount that will be added
     */
    public void addToScore(int number) {
        this.currentScore.increase(number);
    }
}