package arkanoid.gamesetup;

import arkanoid.interfaces.Animation;
import arkanoid.interfaces.LevelInformation;

public class GameFlow {
     private AnimationRunner ar;
     private biuoop.KeyboardSensor ks;
     private ScoreTrackingListener score;
     private Counter remainingBlocks;
     private Counter remainigBalls;
    public GameFlow() {
        this.ar = new AnimationRunner();
        this.ks = ar.getGui().getKeyboardSensor();
        this.score = new ScoreTrackingListener(new Counter());
        this.remainingBlocks = new Counter();
        this.remainigBalls = new Counter();

    }

    public void runLevels(java.util.List<LevelInformation> levels) {
        for (int i = 0; i < levels.size(); i++) {
            GameLevel level = new GameLevel(levels.get(i),this.ar,this.ks,this.score);
            level.initialize();
            level.run();
            }
        Animation win = new KeyPressStoppableAnimation(this.ks, "space", new WinScreen(this.ks, this.score));
        this.ar.run(win);
        this.ar.getGui().close();
        }
    }

