package arkanoid.gamesetup;

import arkanoid.interfaces.Animation;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

public class WinScreen implements Animation {
    private KeyboardSensor keyboard;
    private boolean stop;
    private ScoreTrackingListener score;

    /**
     * constructor for win screen.
     * @param k get the keyboard sensor
     */
    public WinScreen(KeyboardSensor k, ScoreTrackingListener score) {
        this.keyboard = k;
        this.stop = false;
        this.score = score;
    }
    @Override
    public void doOneFrame(DrawSurface d) {
        d.drawText((d.getWidth() / 2) - 200, d.getHeight() / 2, "You Win! Your score is: "
                + String.valueOf(this.score.getScore()), 32);
    }
    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}
