package arkanoid.gamesetup;

import arkanoid.interfaces.*;
import arkanoid.shapes.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sean azenilok 209114370
 * create an enviorment that will hold all collidable objects
 */
public class GameEnvironment {
    private List<Collidable> collidables;

    /**
     * constructor for GameEnviorments.
     */
    public GameEnvironment() {
        collidables = new ArrayList<>();
    }

    /**
     * add the given collidable to the environment.
     * @param c that collidable that will be added
     */
    public void addCollidable(Collidable c) {
        this.collidables.add(c);
    }

    /**
     * remove a given collidable from the enviorment.
     * @param c the collidable that will be removed
     */
    public void removeCollidable(Collidable c) {
        this.collidables.remove(c);
    }

    /**
     * get the closest collision point of all collidables with a given line.
     * if no collision occurred return null.
     * @param trajectory that line that collision will be checked with
     * @return type collisionInfo (info about the collision)
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        CollisionInfo closest = null;
        //check if the list of objects is empty
        if (this.collidables.isEmpty()) {
            return null;
        } else {
            for (int i = 0; i < this.collidables.size(); i++) {
                //get all collision points
                if (trajectory.closestIntersectionToStartOfLine(this.collidables.get(i).
                        getCollisionRectangle()) != null) {
                    if (closest == null) {
                        closest = new CollisionInfo(trajectory.
                                closestIntersectionToStartOfLine(this.collidables.get(i).getCollisionRectangle()),
                                this.collidables.get(i));
                    } else { //if closest is not empty
                        if (trajectory.start().distance(closest.collisionPoint())
                                > trajectory.start().distance(trajectory.
                                closestIntersectionToStartOfLine(this.collidables.get(i).getCollisionRectangle()))) {
                            closest = new CollisionInfo(trajectory.
                                    closestIntersectionToStartOfLine(this.collidables.get(i).getCollisionRectangle()),
                                    this.collidables.get(i));
                        }
                    }
                }
            }
            return closest;
        }
    }
}