package arkanoid.gamesetup;

import arkanoid.interfaces.HitListener;
import arkanoid.shapes.Ball;
import arkanoid.shapes.Block;

/**
 * listener to remove balls.
 * @author sean azenilok 209114370
 */
public class BallRemover implements HitListener {

    private GameLevel game;
    private Counter remainingBalls;

    /**
     * constructor.
     * @param game the game object
     * @param remainingBalls the amount of remainingBalls
     */
    public BallRemover(GameLevel game, Counter remainingBalls) {
        this.game = game;
        this.remainingBalls = new Counter();
        this.remainingBalls.increase(remainingBalls.getValue());
    }

    /**
     * removes balls that go outbound and decreases the amount of balls.
     * @param beingHit the Block that is being hit
     * @param hitter the Ball that hits the block
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(game);
        this.remainingBalls.decrease(1);
    }

    /**
     * getter for remainingBalls.
     * @return the amount of balls left
     */
    public int getRemainingBalls() {
        return this.remainingBalls.getValue();
    }
}
