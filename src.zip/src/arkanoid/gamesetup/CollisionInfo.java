package arkanoid.gamesetup;

import arkanoid.interfaces.*;
import arkanoid.shapes.*;

/**
 * gives info on a given collision.
 */
public class CollisionInfo {
    private Point collisionPoint;
    private Collidable collisionObject;

    /**
     * the point at which the collision occurs.
     * @param collisionPoint the Point where collision occurred
     * @param collisionObject the type of object we collided with
     */
    public CollisionInfo(Point collisionPoint, Collidable collisionObject) {
        this.collisionObject = collisionObject;
        this.collisionPoint = collisionPoint;
    }

    /**
     * get the collisionPoint.
     * @return the collision point
     */
    public Point collisionPoint() {
        return this.collisionPoint;
    }

    /**
     * get the collision object.
     * @return the collidable object involved in the collision.
     */
    public Collidable collisionObject() {
        return this.collisionObject;
    }
}