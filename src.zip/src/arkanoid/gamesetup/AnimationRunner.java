package arkanoid.gamesetup;

import arkanoid.interfaces.Animation;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

public class AnimationRunner {
    private GUI gui;
    private int framesPerSecond;
    private Sleeper sleeper;

    /**
     * constructor.
     */
    public AnimationRunner() {
        this.framesPerSecond = 60; //choose the fps
        this.sleeper = new Sleeper();
        this.gui = new GUI("Arkanoid", 800, 600); // set the board
    }
    /**
     * running the animation.
     * @param animation gets the Animation methods.
     */
    public void run(Animation animation) {
        int millisecondsPerFrame = 1000 / this.framesPerSecond;
        while (!animation.shouldStop()) { //true until the game should stop
            long startTime = System.currentTimeMillis(); //timing
            DrawSurface d = gui.getDrawSurface(); //get the draw surface
            animation.doOneFrame(d); //draws one frame of the game

            gui.show(d);
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                this.sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
    public GUI getGui() {
        return this.gui;
    }
}