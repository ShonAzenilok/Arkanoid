package arkanoid.gamesetup;

import arkanoid.interfaces.Animation;
import biuoop.DrawSurface;
import biuoop.Sleeper;

import java.awt.*;

/**
 * @author sean azenilok 209114370
 * The CountdownAnimation will display the given gameScreen,
 * for numOfSeconds seconds, and on top of them it will show
 * a countdown from countFrom back to 1, where each number will
 * appear on the screen for (numOfSeconds / countFrom) seconds, before
 * it is replaced with the next one.
 */

public class CountdownAnimation implements Animation {
    private SpriteCollection sprites;
    private double numOfSeconds; //number of seconds to wait between every number
    private int countFrom; //what integer to start counting from
    private Sleeper sleeper;
    private boolean stop;
    private boolean firstRun; // on first run we should not wait to draw everything on the screen.
    public CountdownAnimation(double numOfSeconds, int countFrom, SpriteCollection gameScreen) {
        this.sprites = gameScreen;
        this.numOfSeconds = numOfSeconds;
        this.countFrom = countFrom;
        this.stop = false;
        this.sleeper = new Sleeper();
        this.firstRun = true;
    }
    @Override
    public void doOneFrame(DrawSurface d) {
        if (this.countFrom == 0) {
            this.stop = true;
        }
        // draw everything on the screen
        this.sprites.drawAllOn(d);
        d.setColor(Color.red);
        d.drawText(d.getHeight() / 2 + 100, d.getHeight() / 2, String.valueOf(this.countFrom), 100);
        if (this.firstRun) { // if it's the first run don't sleep
            this.firstRun = false;
        } else {
            this.sleeper.sleepFor((long) (this.numOfSeconds * 1000)); // sleep for num of seconds.
        }
        this.countFrom = this.countFrom - 1;


    }
    @Override
    public boolean shouldStop() { return this.stop; }
}