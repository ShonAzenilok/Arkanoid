package arkanoid.gamesetup;

import arkanoid.interfaces.Sprite;
import biuoop.DrawSurface;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sean azenilok 209114370.
 * create a ArrayList that holds sprites.
 */
public class SpriteCollection {
    private List<Sprite> sprites;

    /**
     * create a new Sprite Collection object.
     */
    public SpriteCollection() {
        sprites = new ArrayList<>();
    }

    /**
     * add a new sprite to the list.
     * @param s that sprite that will be added
     */
    public void addSprite(Sprite s) {
        this.sprites.add(s);
    }

    /**
     * remove a sprite from the list.
     * @param s the sprite that will be removed
     */
    public void removeSprite(Sprite s) {
        this.sprites.remove(s);
    }
    /**
     * call timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        for (int i = 0; i < this.sprites.size(); i++) {
            this.sprites.get(i).timePassed();
        }
    }

    /**
     * call drawOn(d) on all sprites.
     * @param d the DrawSurface
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite sprite : this.sprites) {
            sprite.drawOn(d);
        }
    }
}