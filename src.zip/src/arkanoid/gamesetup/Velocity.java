package arkanoid.gamesetup;
import arkanoid.shapes.Point;
/**
 * @author sean azenilok 209114370
 * a new object of type Velocity.
 */
public class Velocity {
    private double dx;
    private double dy;
    /**
     * Instantiates a new Velocity.
     * @param dx the dx
     * @param dy the dy
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
    /**
     * From angle and speed velocity. calculates dx and dy with trigonometry.
     * @param angle the angle
     * @param speed the speed
     * @return the new velocity
     */
    public Velocity fromAngleAndSpeed(double angle, double speed) {
        double r = Math.toRadians(angle);
        double dx = ((Math.sin(r)) * speed);
        double dy = -((Math.cos(r)) * speed);
        return new Velocity(dx, dy);
    }

    /**
     * dx getter.
     * @return the dx
     */
    public double getDx() {
        return this.dx;
    }
    /**
     * dy getter.
     * @return the dy
     */
    public double getDy() {
        return this.dy;
    }

    /**
     * Apply to point its velocity.
     * @param p the point
     * @return the new position of the point
     */
    public Point applyToPoint(Point p) {
        return new Point(p.getX() + this.dx, p.getY() + this.dy);
    }
}