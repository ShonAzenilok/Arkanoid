package arkanoid.shapes;

import arkanoid.gamesetup.GameLevel;
import arkanoid.gamesetup.Velocity;
import arkanoid.interfaces.Collidable;
import arkanoid.interfaces.HitListener;
import arkanoid.interfaces.HitNotifier;
import arkanoid.interfaces.Sprite;
import biuoop.DrawSurface;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.max;
import static java.lang.Math.min;

/**
 * @author sean azenilok 209114370
 * Block object that is collidable.
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private Rectangle rectangle;
    private java.awt.Color fillcolor;
    private java.awt.Color bordercolor;
    private List<HitListener> hitListeners;

    /**
     * creates a Block.
     * @param rectangle the block position
     * @param fillcolor block fill color
     * @param bordercolor block border color
     */
    public Block(Rectangle rectangle, java.awt.Color fillcolor, java.awt.Color bordercolor) {
        this.rectangle = rectangle;
        this.fillcolor = fillcolor;
        this.bordercolor = bordercolor;
        this.hitListeners = new ArrayList<>();
    }
    /**
     * getter for rectangle.
     * @return this rectangle
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this.rectangle;
    }

    /**
     * check if there was a collision with a block if so change the velocity.
     * @param collisionPoint the point of collision
     * @param currentVelocity the current velocity of a ball
     * @return the updated velocity of a ball
     */
    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        //get all the lines of the rectangle;
        Line lowerLine = this.rectangle.getLowerLine();
        Line upperLine = this.rectangle.getUpperLine();
        Line leftSide = this.rectangle.getLeftSide();
        Line rightSide = this.rectangle.getRightSide();
        //get all the side points
        Point ul = this.rectangle.getUpperLeft();
        Point dl = new Point(this.rectangle.getUpperLeft().getX(), this.rectangle.getUpperLeft().getY()
                + this.rectangle.getHeight());
        Point ur = new Point(this.rectangle.getUpperLeft().getX() + this.rectangle.getWidth(),
                this.rectangle.getUpperLeft().getY());
        Point dr = new Point(this.rectangle.getUpperLeft().getX() + this.rectangle.getWidth(),
                this.rectangle.getUpperLeft().getY() + this.rectangle.getHeight());
        //check collision with the corners
        if (collisionPoint.equals(ul) || collisionPoint.equals(ur) || collisionPoint.equals(dl)
                || collisionPoint.equals(dr)) {
            this.notifyHit(hitter);
            return new Velocity(-currentVelocity.getDx(), -currentVelocity.getDy());
        }

        //check for upper,lower,left,right.
        if (collisionPoint.getX() >= min(upperLine.start().getX(), upperLine.end().getX())
                && collisionPoint.getX() <= max(upperLine.start().getX(), upperLine.end().getX())
                && upperLine.doubleCompare(upperLine.start().getY(), collisionPoint.getY())) {
            this.notifyHit(hitter);
            return new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
        } else if (collisionPoint.getX() >= min(lowerLine.start().getX(), lowerLine.end().getX())
                && collisionPoint.getX() <= max(lowerLine.start().getX(), lowerLine.end().getX())
                && lowerLine.doubleCompare(lowerLine.start().getY(), collisionPoint.getY())) {
            this.notifyHit(hitter);
            return new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
        } else if (collisionPoint.getY() >= min(leftSide.start().getY(), leftSide.end().getY())
                && collisionPoint.getY() <= max(leftSide.start().getY(), leftSide.end().getY())
                && leftSide.doubleCompare(leftSide.start().getX(), collisionPoint.getX())) {
            this.notifyHit(hitter);
            return new Velocity(-currentVelocity.getDx(), currentVelocity.getDy());
        } else {
            this.notifyHit(hitter);
            return new Velocity(-currentVelocity.getDx(), currentVelocity.getDy());
        }
    }


    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(this.fillcolor);
        d.fillRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(),
                (int) this.rectangle.getHeight());
        d.setColor(this.bordercolor);
        d.drawRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(),
                (int) this.rectangle.getHeight());
    }

    @Override
    public void timePassed() {
     //do nothing for now
    }
    /**
     * adds a Block to the game.
     * @param g the game class
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * remove a block from the game.
     * @param game the game class
     */
    public void removeFromGame(GameLevel game) {
        game.removeSprite(this);
        game.removeCollidable(this);
    }

    @Override
    public void addHitListener(HitListener hl) {
        hitListeners.add(hl);

    }

    @Override
    public void removeHitListener(HitListener hl) {
        hitListeners.remove(hl);
    }

    /**
     * notifies all the listener list about a new hit.
     * @param hitter the ball that hit the listener
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }

    /**
     * changes the color of the block.
     * @param color the color that the block will have
     */
    public void setColor(Color color) {
        this.fillcolor = color;
    }
}
