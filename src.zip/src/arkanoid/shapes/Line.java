package arkanoid.shapes;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.max;
import static java.lang.Math.min;

/**
 * @ sean azenilok 209114370
 * The object Line
 */
public class Line {
    private final double threshold = 0.00001;
    private double x1;
    private double x2;
    private double y1;
    private double y2;

    /**
     * Instantiates a new Line.
     *
     * @param start start point
     * @param end   end point
     */
    public Line(Point start, Point end) {
        this.x1 = start.getX();
        this.y1 = start.getY();
        this.x2 = end.getX();
        this.y2 = end.getY();
    }

    /**
     * Instantiates a new Line.
     *
     * @param x1 the x 1
     * @param y1 the y 1
     * @param x2 the x 2
     * @param y2 the y 2
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    /**
     * compare two double values.
     * @param a first variable
     * @param b second variable
     * @return true of point are equal according to threshold
     */
    public boolean doubleCompare(double a, double b) {
        return Math.abs(a - b) <= threshold;
    }


    /**
     * Length get the length of the line.
     * @return the length
     */
    public double length() {
        return start().distance(end());
    }

    /**
     * get middle of line by mathematical formula.
     * @return the point of middle
     */
    public Point middle() {
        return new Point(((this.x1 + this.x2) / 2), ((this.y1 + this.y2) / 2));
    }

    /**
     * get the start point of the line.
     * @return the point
     */
    public Point start() {
        return new Point(this.x1, this.y1);
    }

    /**
     * get the end point of the line.
     * @return the point
     */
    public Point end() {
        return new Point(this.x2, this.y2);
    }
    /**
     * isIntersection check of two lines are intersecting return true or
     * false accordingly.
     * @param other the other line that we check intersection with
     * @return the boolean
     */
    public boolean isIntersecting(Line other) {
        //first we will find the m and b
        //m (slope) value
        double firstSlope = ((this.y2 - this.y1) / (this.x2 - this.x1));
        double otherSlope = ((other.y2 - other.y1) / (other.x2 - other.x1));

        /* check if slopes are zero */
        if (doubleCompare(firstSlope, 0)) {
            firstSlope = 0;
        }
        if (doubleCompare(otherSlope, 0)) {
            otherSlope = 0;
        }


        //b (intercept) value
        double firstIntercept = firstSlope * (-this.x1) + this.y1;
        double otherIntercept = otherSlope * (-other.x1) + other.y1;

        //then we will calculate the Intersection
        double intersectionX = ((otherIntercept - firstIntercept) / (firstSlope - otherSlope));
        double intersectionY = firstSlope * (intersectionX - this.x1) + this.y1;

        //and calculate intersection if a line is vertical
        if (Double.isInfinite(firstSlope) || Double.isInfinite(otherSlope)) {
            if (Double.isInfinite(firstSlope)) {
                intersectionX = this.x1;
                intersectionY = otherSlope * this.x1 + otherIntercept;
            }
            if (Double.isInfinite(otherSlope)) {
                intersectionX = other.x1;
                intersectionY = firstSlope * other.x1 + firstIntercept;
            }
            if (Double.isInfinite(firstSlope) && Double.isInfinite(otherSlope)) {
                //if they touch on one end
                intersectionX = this.x1;
                if (doubleCompare(this.y1, other.y1) || doubleCompare(this.y1, other.y2)) {
                    intersectionY = this.y1;
                } else if (doubleCompare(this.y2, other.y1) || doubleCompare(this.y2, other.y2)) {
                    intersectionY = this.y2;
                } else {
                    //if they collide
                    return false;
                }
            }
            //if slopes are equal
        }
        if (doubleCompare(firstSlope, otherSlope) && doubleCompare(firstIntercept, otherIntercept)) {
            //if they touch
            return doubleCompare(this.x1, other.x1) && doubleCompare(this.y1, other.y1)
                    || doubleCompare(this.x1, other.x2) && doubleCompare(this.y1, other.y2)
                    || doubleCompare(this.x2, other.x1) && doubleCompare(this.y2, other.y1)
                    || doubleCompare(this.x2, other.x2) && doubleCompare(this.y2, other.y2);
        }
        //check if parallel horizontally
        if (firstSlope == otherSlope && firstIntercept != otherIntercept) {
            return false;
            // check if parallel vertically
        } else if (Double.isInfinite(firstIntercept) && Double.isInfinite(otherIntercept)
                && !doubleCompare(this.x1, other.x1)) {
            return false;
            //check if the intersection is between the Lines
        }  else if ((intersectionX <= max(this.x1, this.x2) && intersectionX >= min(this.x1, this.x2)
                && intersectionY <= max(this.y1, this.y2) && intersectionY >= min(this.y1, this.y2)
                && intersectionX <= max(other.x1, other.x2) && intersectionX >= min(other.x1, other.x2)
                && intersectionY <= max(other.y1, other.y2) && intersectionY >= min(other.y1, other.y2))) {

            return true; //check if there is intersection on the Line edge
        } else {
            return ((doubleCompare(intersectionX, this.x1) && doubleCompare(intersectionY, this.y1))
                    || (doubleCompare(intersectionX, this.x2) && doubleCompare(intersectionY, this.y2)))
                    && ((doubleCompare(intersectionX, other.x1) && doubleCompare(intersectionY, other.y1))
                    || (doubleCompare(intersectionX, other.x2) && doubleCompare(intersectionY, other.y2)));
        }
    }

    /**
     * get the point of intersection if two lines intersect.
     * @param other the Line we check intersection with
     * @return the point of intersection
     */
    public Point intersectionWith(Line other) {

        if (this.isIntersecting(other)) {
            //first we will find the m and b
            //m (slope) value
            double firstSlope = ((this.y2 - this.y1) / (this.x2 - this.x1));
            double otherSlope = ((other.y2 - other.y1) / (other.x2 - other.x1));

            /* check if slopes are zero for better accuracy */
            if (doubleCompare(firstSlope, 0)) {
                firstSlope = 0;
            }
            if (doubleCompare(otherSlope, 0)) {
                otherSlope = 0;
            }


            //b (intercept) value
            double firstIntercept = firstSlope * (-this.x1) + this.y1;
            double otherIntercept = otherSlope * (-other.x1) + other.y1;

            //then we will calculate the Intersection in case of normal intersection
            double intersectionX = ((otherIntercept - firstIntercept) / (firstSlope - otherSlope));
            double intersectionY = firstSlope * (intersectionX - this.x1) + this.y1;

            //and calculate intersection if a line is vertical
            if (Double.isInfinite(firstSlope) || Double.isInfinite(otherSlope)) {
                if (Double.isInfinite(firstSlope)) {
                    intersectionX = this.x1;
                    intersectionY = otherSlope * this.x1 + otherIntercept;
                }
                if (Double.isInfinite(otherSlope)) {
                    intersectionX = other.x1;
                    intersectionY = firstSlope * other.x1 + firstIntercept;
                }
                if (Double.isInfinite(firstSlope) && Double.isInfinite(otherSlope)) {
                    //if they touch on one end
                    intersectionX = this.x1;
                    if (doubleCompare(this.y1, other.y1) || doubleCompare(this.y1, other.y2)) {
                        intersectionY = this.y1;
                    }
                    if (doubleCompare(this.y2, other.y1) || doubleCompare(this.y2, other.y2)) {
                        intersectionY = this.y2;
                    }
                }
            } /* if slopes are equal */
            else if (doubleCompare(firstSlope, otherSlope) && doubleCompare(firstIntercept, otherIntercept)) {
                //if they touch
                if (doubleCompare(this.x1, other.x1) && doubleCompare(this.y1, other.y1)) {
                    intersectionX = this.x1;
                    intersectionY = this.y1;
                } else if (doubleCompare(this.x1, other.x2) && doubleCompare(this.y1, other.y2)) {
                    intersectionX = this.x1;
                    intersectionY = this.y1;
                } else if (doubleCompare(this.x2, other.x1) && doubleCompare(this.y2, other.y1)) {
                    intersectionX = this.x2;
                    intersectionY = this.y2;
                } else if (doubleCompare(this.x2, other.x2) && doubleCompare(this.y2, other.y2)) {
                    intersectionX = this.x2;
                    intersectionY = this.y2;
                }
            }
            //return the intersection point
            return new Point(intersectionX, intersectionY);
        } else {
            return null;
        }
    }

    /**
     * checks if two lines are equal.
     * @param other the line we check with
     * @return the boolean
     */
    public boolean equals(Line other) {
        return (this.x1 == other.x1 && this.x2 == other.x2 && this.y1 == other.y1 && this.y2 == other.y2)
                || (this.y1 == other.x1 && this.y2 == other.x2 && this.x1 == other.y1 && this.x2 == other.y2);
    }
    /**
     *If this line does not intersect with the rectangle, return null.
     *Otherwise, return the closest intersection point to the
     * start of the line.
     * @param rect that we check intersection with
     * @return the closest point or null (in case of no intersection)
     */
        public Point closestIntersectionToStartOfLine(Rectangle rect) {
            Line thisLine = new Line(this.start(), this.end()); // create this line
            List<Point> list = new ArrayList<>();
            list = rect.intersectionPoints(thisLine);
            //check if no intersection points
            if (list.size() == 0) {
                return null;
            }
            //calculate all distances into array
            double[] distance = new double[list.size()];
            for (int i = 0; i < list.size(); i++) {
                distance[i] = thisLine.start().distance(list.get(i));
            }
            //get minimum distance index
            int j = 0;
            for (int i = 0; i < distance.length; i++) {
                if (distance[j] > distance[i]) {
                    j = i;
                }
            }
            return list.get(j); //return the closest intersectionPoint
        }
}