package arkanoid.shapes;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sean azenilok 209114370
 * Rectangle object class.
 */
public class Rectangle {
    private Point upperleft;
    private double width;
    private double height;
    //coordinates  of the rectangle
    private Line upperLine;
    private Line leftSide;
    private Line rightSide;
    private Line lowerLine;

    /**
     * Create a new rectangle with location and width/height.
     * @param upperLeft upper left coordinates
     * @param width rectangle width
     * @param height rectangle height
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperleft = upperLeft;
        this.width = width;
        this.height = height;
        this.upperLine = new Line(upperLeft, new Point(upperLeft.getX() + width, upperLeft.getY()));
        this.leftSide = new Line(upperLeft, new Point(upperLeft.getX(), upperLeft.getY() + height));
        this.rightSide = new Line(upperLeft.getX() + width, upperLeft.getY(),
                upperLeft.getX() + width, upperLeft.getY() + height);
        this.lowerLine = new Line(upperLeft.getX(), upperLeft.getY() + height,
                upperLeft.getX() + width, upperLeft.getY() + height);
    }

    /**
     * Return a (possibly empty) List of intersection points
     * with the specified line.
     * @param line the line a Rectangle intersecets with
     * @return list of intersection points
     */
    public java.util.List<Point> intersectionPoints(Line line) {
        Point[] intersectionPoints = new Point[4];
        List<Point> hits = new ArrayList<>(); //create a new list
        //put all intersection points in the array
        intersectionPoints[0] = this.upperLine.intersectionWith(line);
        intersectionPoints[1] = this.leftSide.intersectionWith(line);
        intersectionPoints[2] = this.rightSide.intersectionWith(line);
        intersectionPoints[3] = this.lowerLine.intersectionWith(line);
        //add points to list
        for (Point interscetionPoint : intersectionPoints) {
            if (interscetionPoint != null) {
                hits.add(interscetionPoint);
            }
        }
        return hits;
    }

    /**
     * getter for width.
     * @return the width
     */
    public double getWidth() {
        return this.width;
    }
    /**
     * getter for height.
     * @return the height
     */
    public double getHeight() {
        return this.height;
    }
    /**
     * getter for the upper left point.
     * @return the upper left point
     */
    public Point getUpperLeft() {
        return this.upperleft;
    }
    /**
     * getter for the upper left line.
     * @return the upper left line
     */
    public Line getUpperLine() {
        return this.upperLine;
    }
    /**
     * getter for the left side.
     * @return the left side
     */
    public Line getLeftSide() {
        return this.leftSide;
    }
    /**
     * getter for the lower line.
     * @return the lower line
     */
    public Line getLowerLine() {
        return this.lowerLine;
    }
    /**
     * getter for the right side.
     * @return the right side
     */
    public Line getRightSide() {
        return this.rightSide;
    }
}