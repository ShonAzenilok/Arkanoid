package arkanoid.shapes;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import arkanoid.gamesetup.*;
import arkanoid.interfaces.*;

import java.awt.*;

/**
 * object of type paddle that is also a sprite and a collidable.
 */
public class Paddle implements Sprite, Collidable {
    private biuoop.KeyboardSensor keyboard;
    private Rectangle rectangle;
    private java.awt.Color fillColor;
    private java.awt.Color borderColor;
    private int paddleSpeed;
    /**
     * constructor for paddle.
     * @param rectangle paddle location
     * @param fillColor the color that fills the paddle
     * @param borderColor the color that will be at the border of paddle
     * @param game the game environment (needed to set up keyboard)
     * @param speed the speed of the paddle
     */
    public Paddle(Rectangle rectangle, Color fillColor, Color borderColor, GameLevel game, int speed) {
        this.rectangle = rectangle;
        this.fillColor = fillColor;
        this.borderColor = borderColor;
        this.keyboard = game.getKeyboard();
        this.paddleSpeed = speed;
    }

    /**
     * move the paddle to the left.
     */
    public void moveLeft() {
        if (this.keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            if (this.rectangle.getUpperLeft().getX() >= 46) {
                if (this.rectangle.getUpperLeft().getX() - this.paddleSpeed >= 46) {
                    this.movePaddle(-this.paddleSpeed);
                } else {
                    this.rectangle = new Rectangle(new Point(45 + this.paddleSpeed,
                            this.rectangle.getUpperLeft().getY()), this.rectangle.getWidth(),
                            this.rectangle.getHeight());

                }

            }
        }
    }

    /**
     * move the paddle to the right.
     */
    public void moveRight() {
        if (this.keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            if ((this.rectangle.getUpperLeft().getX() + this.rectangle.getWidth()) <= 748) {
                if ((this.rectangle.getUpperLeft().getX() + this.rectangle.getWidth() + this.paddleSpeed) <= 749) {
                    this.movePaddle(paddleSpeed);
                } else {
                    this.rectangle = new Rectangle(new Point(750 - this.rectangle.getWidth(),
                            this.rectangle.getUpperLeft().getY()), this.rectangle.getWidth(),
                            this.rectangle.getHeight());
                }
            }
        }

    }

    /**
     * moves the paddle according to the key pressed.
     */
    public void timePassed() {
        this.moveLeft();
        this.moveRight();
    }

    /**
     * draws the paddle.
     * @param d the given drawSurface
     */
    public void drawOn(DrawSurface d) {
        d.setColor(this.fillColor);
        d.fillRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(),
                (int) this.rectangle.getHeight());
        d.setColor(this.borderColor);
        d.drawRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(),
                (int) this.rectangle.getHeight());
    }

    /**
     * get the collision object.
     * @return the paddle rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.rectangle;
    }

    /**
     * checks for a collision with the paddle.
     * @param hitter that ball that hit the paddle
     * @param collisionPoint a point where collision occurred
     * @param currentVelocity the currents velocity of the object that we collided with
     * @return the new velocity
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        Line lowerLine = this.rectangle.getLowerLine();
        Line upperLine = this.rectangle.getUpperLine();
        Line leftSide = this.rectangle.getLeftSide();
        Line rightSide = this.rectangle.getRightSide();
        //split the paddle to 5 regions
        double r0 = this.rectangle.getUpperLeft().getX();
        double r1 = (double) (this.rectangle.getWidth() / 5) + this.rectangle.getUpperLeft().getX();
        double r2 = (double) (this.rectangle.getWidth() / 5) * 2 + this.rectangle.getUpperLeft().getX();
        double r3 = (double) (this.rectangle.getWidth() / 5) * 3 + this.rectangle.getUpperLeft().getX();
        double r4 = (double) (this.rectangle.getWidth() / 5) * 4 + this.rectangle.getUpperLeft().getX();
        double r5 = this.rectangle.getWidth() + this.rectangle.getUpperLeft().getX();
        //if the collision point is on the lower or upper line
        if (upperLine.doubleCompare(collisionPoint.getY(), this.rectangle.getUpperLine().start().getY())) {
            //check
            if (r0 <= collisionPoint.getX() && collisionPoint.getX() < r1) { //region 1
                return currentVelocity.fromAngleAndSpeed(300, 4);
            } else if (r1 <= collisionPoint.getX() && collisionPoint.getX() < r2) { //region 2
                return currentVelocity.fromAngleAndSpeed(330, 4);
            } else if (r2 <= collisionPoint.getX() && collisionPoint.getX() < r3) { //region 3
                return new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
            } else if (r3 <= collisionPoint.getX() && collisionPoint.getX() < r4) { //region 4
                return currentVelocity.fromAngleAndSpeed(30, 4);
            } else if (r4 <= collisionPoint.getX() && collisionPoint.getX() <= r5) { //region 5
                return currentVelocity.fromAngleAndSpeed(60, 4);
            }
            //if the collision point is not on top
        } else {
            //if keyboard is pressed move the paddle a bit to the side so the ball won't go in
            if (this.keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
                if (this.rectangle.getUpperLeft().getX() >= 55) {
                   this.movePaddle(this.paddleSpeed * 2);
                }
            } else if (this.keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
                if (this.rectangle.getUpperLeft().getX() >= 55) {
                    this.movePaddle(-(this.paddleSpeed * 2));
                }
            }
            return new Velocity(-currentVelocity.getDx(), -currentVelocity.getDy());
        }
        return currentVelocity;
    }


    /**
     * adds paddle as object in the game.
     * @param g the game object
     */
    public void addToGame(GameLevel g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

    /**
     * move the paddle.
     * @param paddleSpeed the amount to move the paddle by
     */
    private void movePaddle(int paddleSpeed) {
        this.rectangle = new Rectangle(new Point(this.rectangle.getUpperLeft().getX() + paddleSpeed,
                this.rectangle.getUpperLeft().getY()), this.rectangle.getWidth(),
                this.rectangle.getHeight());

    }
}