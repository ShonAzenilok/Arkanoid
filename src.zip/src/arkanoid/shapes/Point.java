package arkanoid.shapes;

/**
 * @author sean azenilok 209114370
 * class of the point object
 */
public class Point {
    private double x;
    private final double threshold = 0.00001;
    private double y;
    // constructor
    /**
     * constructor of Point.
     * @param x the x
     * @param y the y
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * threshold comparison of doubles.
     * @param a first double
     * @param b second double
     * @return true or false if they are equel
     */
    public boolean doubleCompare(double a, double b) {
        return Math.abs(a - b) <= threshold;
    }

    /**
     * calculate the distance of 2 points,
     *by the mathematical formula of distance.
     * @param other of type point
     * @return the distance between two points
     */
    public double distance(Point other) {
        return Math.sqrt(((this.x - other.getX()) * (this.x - other.getX()))
                + ((this.y - other.getY()) * (this.y - other.getY())));
    }

    /**
     * check if two point are at the same place.
     * @param other the point we check equality with
     * @return the boolean
     */
    public boolean equals(Point other) {
        return (doubleCompare(this.x, other.getX()) && doubleCompare(this.y, other.getY()));
    }
    /**
     * getter for x.
     * @return the x value
     */
    public double getX() {
        return this.x;
    }
    /**
     * getter.
     * @return the y
     */
    public double getY() {
        return this.y;
    }
    /**
     * setter for x.
     * @param x a value from the user
     */
    public void setX(double x) {
        this.x = x;
    }
    /**
     * setter for y.
     * @param y a value from the user
     */
    public void setY(double y) {
        this.y = y;
    }

}