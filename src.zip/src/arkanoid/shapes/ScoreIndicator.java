package arkanoid.shapes;

import arkanoid.gamesetup.GameLevel;
import arkanoid.interfaces.Sprite;
import biuoop.DrawSurface;

import java.awt.*;

/**
 * Score indicator sprite.
 */
public class ScoreIndicator implements Sprite {
    private Rectangle rectangle;
    private int score;
    private String levelName;

    /**
     * consturctor.
     * @param rectangle get a rectangle that will be around the score
     * @param levelName the level name
     */
    public ScoreIndicator(Rectangle rectangle, String levelName) {
        this.rectangle = rectangle;
        this.score = 0;
        this.levelName = levelName;
    }

    /**
     * setter for score.
     * @param score the score that will be set
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * getter for score.
     * @return the score
     */
    public int getScore() {
        return this.score;
    }

    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(Color.lightGray);
        d.fillRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(),
                (int) this.rectangle.getHeight());
        d.setColor(Color.black);
        d.drawRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(),
                (int) this.rectangle.getHeight());
        d.drawText((int) ((((int) this.rectangle.getUpperLeft().getX() + this.rectangle.getWidth()) / 2) - 50),
                (int) (this.rectangle.getUpperLeft().getY() + this.rectangle.getHeight()) - 10,
                "Score: " + this.score + "       Level Name: " + this.levelName, 20);
    }

    @Override
    public void timePassed() {
    }
    /**
     * adds a scoreindicator to the game.
     * @param g the game class
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
}
