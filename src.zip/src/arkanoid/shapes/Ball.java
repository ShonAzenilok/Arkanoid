package arkanoid.shapes;

import arkanoid.gamesetup.*;
import arkanoid.interfaces.*;
import biuoop.DrawSurface;
import biuoop.GUI;
/**
 * @author sean azenilok 209114370
 * The Object Ball implements Sprite
 */
public class Ball implements Sprite {
    private GameEnvironment game;
    private Velocity v;
    private Point center;
    private int r;
    private java.awt.Color fillColor;
    private java.awt.Color borderColor;

    private static int wait = 0, r1 = 0;
    private static boolean up = true;

    /**
     * instantiates a new ball. and sets it velocity to 0
     * @param center the center point of a ball
     * @param r the radius of a ball
     * @param fillColor the inside color
     * @param borderColor the border color
     * @param game game environment variable
     */
    public Ball(Point center, int r, java.awt.Color fillColor, java.awt.Color borderColor, GameEnvironment game) {
        this.center = center;
        this.r = r;
        this.fillColor = fillColor;
        this.borderColor = borderColor;
        this.v = new Velocity(0, 0);
        this.game = game;
    }

    /**
     * Instantiates a new Ball.
     * and sets it velocity to 0.
     * @param x     the x
     * @param y     the y
     * @param r     the radius of the ball
     * @param fillColor the inside color
     * @param borderColor the border color
     * @param game game enviorment variable
     */
    public Ball(int x, int y, int r, java.awt.Color fillColor, java.awt.Color borderColor, GameEnvironment game) {
        this.center = new Point(x, y);
        this.r = r;
        this.fillColor = fillColor;
        this.borderColor = borderColor;
        this.v = new Velocity(0, 0);
        this.game = game;
    }

    /**
     * Gets x coordinate of a ball.
     * @return the x integer
     */
// accessors
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * Gets y coordinate of a ball.
     * @return the y integer
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * Gets radius.
     * @return the radius
     */
    public int getSize() {
        return this.r;
    }

    /**
     * Getter for color.
     * @return the fill color
     */
    public java.awt.Color getFillColor() {
        return this.fillColor;
    }

    /**
     * Draw ball on given DrawSurface.
     * @param d the surface
     */
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(this.fillColor);
        d.fillCircle(this.getX(), this.getY(), this.getSize());
        d.setColor(this.borderColor);
        d.drawCircle(this.getX(), this.getY(), this.getSize());
    }

    /**
     * Setter for velocity.
     * @param v the new velocity
     */
    public void setVelocity(Velocity v) {
        this.v = v;
    }

    /**
     * Setter for velocity.
     * @param dx the new dx
     * @param dy the new dy
     */
    public void setVelocity(double dx, double dy) {
        this.v = new Velocity(dx, dy);
    }

    /**
     * getter of velocity.
     * @return current velocity
     */
    public Velocity getVelocity() {
        return this.v;
    }

    /**
     * MoveOneStep checks if a ball touches the edges of the gui if so reverses its velocity
     * and moves the ball according to the velocity.
     * @param gui the gui
     */
    public void moveOneStep(GUI gui) {
        if ((this.center.getX() + this.r) >= gui.getDrawSurface().getWidth()
                || (this.center.getX() - this.r) <= 0) {
            setVelocity(-this.v.getDx(), this.v.getDy());
        }
        if ((this.center.getY() + this.r) >= gui.getDrawSurface().getHeight()
                || (this.center.getY() - this.r) <= 0) {
            setVelocity(this.v.getDx(), -this.v.getDy());
        }
        this.center = this.getVelocity().applyToPoint(this.center);
        /*check if the ball is out of bounds after moving him if so
        move the ball to the edge of the bound.*/
        if ((this.center.getX() + this.r) >= gui.getDrawSurface().getWidth()) {
            this.center.setX(gui.getDrawSurface().getWidth() - this.r);
        }
        if ((this.center.getX() - this.r) <= 0) {
            this.center.setX(this.r);
        }
        if ((this.center.getY() + this.r) >= gui.getDrawSurface().getHeight()) {
             this.center.setY(gui.getDrawSurface().getHeight() - this.r);
        }
        if ((this.center.getY() - this.r) <= 0) {
            this.center.setY(this.r);
        }
    }

    /**
     * moves the ball according to its velocity and checks if there was a collision with a collidable.
     */
    public void moveOneStep() {
        /*compute that ball trajectory*/
        //set a new ball that will be on the edge of the ball
        double xVal = this.center.getX();
        double yVal = this.center.getY();
        if (this.v.getDx() > 0) {
            xVal = xVal + this.r;
        } else {
            xVal = xVal - this.r;
        }
        if (this.v.getDy() > 0) {
            yVal = yVal + this.r;
        } else {
            yVal = yVal - this.r;
        }
        Point pointOnBall = new Point(xVal, yVal);
        Point afterV = new Point(pointOnBall.getX() + this.v.getDx(), pointOnBall.getY() + this.v.getDy());
        Line trajectory = new Line(this.center, afterV);
        //check if hit a border or collidable object
        CollisionInfo closestCollision = this.game.getClosestCollision(trajectory);
        if (closestCollision != null) {
           this.center = closestCollision.collisionPoint();
            if (this.v.getDx() > 0) {
                this.center = new Point(this.center.getX()  - (this.r + 1), this.center.getY());
            } else {
                this.center = new Point(this.center.getX()  + (this.r + 1), this.center.getY());
            }
            if (this.v.getDy() > 0) {
                this.center = new Point(this.center.getX(), (this.center.getY() - (this.r + 1)));
            } else {
                this.center = new Point(this.center.getX(), (this.center.getY() + (this.r + 1)));
            }
            this.v = closestCollision.collisionObject().hit(this, closestCollision.collisionPoint(), this.v);
        } else {
            this.center = this.getVelocity().applyToPoint(this.center);
        }
    }

    /**
     * passes time on the board (calls moveOneStep and changes ball color).
     */
    @Override
    public void timePassed() {

        this.moveOneStep();
        if (wait == 11) {
            // Create a new Color object using the generated RGB values

            this.fillColor = new java.awt.Color(255 - r1, r1, r1);
            if (up) {
                r1++;
                if (r1 == 255) {
                    up = false;
                }
            }
            if (!up) {
                r1--;
                if (r1 == 0) {
                    up = true;
                }
            }
            wait = 0;
        }
        wait++;
    }

    /**
     * adds a ball to the game.
     * @param g the game class
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

    /**
     * remove a ball from game.
     * @param g the game that the ball will be removed from
     */
    public void removeFromGame(GameLevel g) {
        g.removeSprite(this);
    }
}
