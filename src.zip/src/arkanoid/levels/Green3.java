package arkanoid.levels;

import arkanoid.gamesetup.Velocity;
import arkanoid.interfaces.LevelInformation;
import arkanoid.interfaces.Sprite;
import arkanoid.shapes.Block;
import arkanoid.shapes.Point;
import arkanoid.shapes.Rectangle;

import java.awt.*;
import java.util.LinkedList;
import java.util.List;

/**
 * level 3 of the game.
 */
public class Green3 implements LevelInformation {
    @Override
    public int numberOfBalls() {
        return 3;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> list = new LinkedList<>();
        for (int i = 0; i < this.numberOfBalls(); i++) {
            list.add(new Velocity(-2, 3));
        }
        return list;
    }

    @Override
    public int paddleSpeed() {
        return 5;
    }

    @Override
    public int paddleWidth() {
        return 100;
    }

    @Override
    public String levelName() {
        return "Green3";
    }

    @Override
    public Sprite getBackground() {
        return new Block(new Rectangle(new Point(0, 0), 800, 600),
                new Color(4, 124, 13), Color.black);
    }

    @Override
    public List<Block> blocks() {
        //create the blocks
        List<Block> blocks = new LinkedList<>();
        //row 1
        for (int i = 0; i < 12; i++) {
            blocks.add(new Block(new Rectangle(new Point(700 - (i * 50), 125), 50, 25),
                    Color.gray, Color.black));
        }
        //row 2
        for (int i = 0; i < 11; i++) {
            blocks.add(new Block(new Rectangle(new Point(700 - (i * 50), 150), 50, 25),
                    Color.red, Color.black));
        }
        //row 3
        for (int i = 0; i < 10; i++) {
            blocks.add(new Block(new Rectangle(new Point(700 - (i * 50), 175), 50, 25),
                    Color.yellow, Color.black));
        }
        //row 4
        for (int i = 0; i < 9; i++) {
            blocks.add(new Block(new Rectangle(new Point(700 - (i * 50), 200), 50, 25),
                    Color.blue, Color.black));
        }
        //row 5
        for (int i = 0; i < 8; i++) {
            blocks.add(new Block(new Rectangle(new Point(700 - (i * 50), 225), 50, 25),
                    Color.pink, Color.black));
        }
        //row 6
        for (int i = 0; i < 7; i++) {
            blocks.add(new Block(new Rectangle(new Point(700 - (i * 50), 250), 50, 25),
                    Color.green, Color.black));
        }
        return blocks;
    }

    @Override
    public int numberOfBlocksToRemove() {
        List<Block> list = this.blocks();
        return list.size();
    }
}
