package arkanoid.levels;

import arkanoid.gamesetup.Velocity;
import arkanoid.interfaces.LevelInformation;
import arkanoid.interfaces.Sprite;
import arkanoid.shapes.Block;
import arkanoid.shapes.Point;
import arkanoid.shapes.Rectangle;

import java.awt.*;
import java.util.LinkedList;
import java.util.List;

/**
 * level with one block that you need to hit directly.
 */

public class DirectHit implements LevelInformation {
    @Override
    public int numberOfBalls() {
        return 1;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> list = new LinkedList<>();
        for (int i = 0; i < this.numberOfBalls(); i++) {
            list.add(new Velocity(0, 3));
        }
        return list;
    }

    @Override
    public int paddleSpeed() {
        return 5;
    }

    @Override
    public int paddleWidth() {
        return 100;
    }

    @Override
    public String levelName() {
        return "Direct Hit";
    }

    @Override
    public Sprite getBackground() {
        return new Block(new Rectangle(new Point(0, 0), 800, 600),
                new Color(0, 0, 0), Color.black);
    }

    @Override
    public List<Block> blocks() {
        // create the list to be returned
        List<Block> list = new LinkedList<>();

        //create all the blocks and add them to list
        list.add(new Block(new Rectangle(new Point(400, 150), 25, 25),
                Color.red, Color.black));

        return list; //return the list
    }

    @Override
    public int numberOfBlocksToRemove() {
        List<Block> list = this.blocks();
        return list.size();
    }
}
