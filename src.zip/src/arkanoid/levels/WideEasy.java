package arkanoid.levels;

import arkanoid.gamesetup.Velocity;
import arkanoid.interfaces.LevelInformation;
import arkanoid.interfaces.Sprite;
import arkanoid.shapes.Block;
import arkanoid.shapes.Point;
import arkanoid.shapes.Rectangle;

import java.awt.*;
import java.util.LinkedList;
import java.util.List;

/**
 * level with large paddle and a lot of balls, very easy level.
 */
public class WideEasy implements LevelInformation {

    @Override
    public int numberOfBalls() {
        return 10;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> list = new LinkedList<>();
        for (int i = 0; i < this.numberOfBalls(); i++) {
            list.add(new Velocity(-2, 3));
        }
        return list;
    }

    @Override
    public int paddleSpeed() {
        return 5;
    }

    @Override
    public int paddleWidth() {
        return 400;
    }

    @Override
    public String levelName() {
        return "Wide Easy";
    }

    @Override
    public Sprite getBackground() {
        return new Block(new Rectangle(new Point(0, 0), 800, 600),
                new Color(255, 255, 255), Color.black);
    }

    @Override
    public List<Block> blocks() {
        // create the list to be returned
        List<Block> list = new LinkedList<>();

        //create all the blocks and add them to list
        for (int i = 0; i < 14; i++) {
            list.add(new Block(new Rectangle(new Point(50 + (i * 50), 250), 50, 25),
                    Color.cyan, Color.black));
            if (0 <= i && i < 2) {
                list.get(i).setColor(Color.red);
            } else if (2 <= i && i < 4) {
                list.get(i).setColor(Color.orange);
            } else if (4 <= i && i < 6) {
                list.get(i).setColor(Color.yellow);
            } else if (6 <= i && i < 8) {
                list.get(i).setColor(Color.green);
            } else if (8 <= i && i < 10) {
                list.get(i).setColor(Color.blue);
            } else if (10 <= i && i < 12) {
                list.get(i).setColor(Color.pink);
            } else if (12 <= i && i < 14) {
                list.get(i).setColor(Color.cyan);
            }
        }

        return list; //return the list
    }

    @Override
    public int numberOfBlocksToRemove() {
        List<Block> list = this.blocks();
        return list.size();
    }
}
